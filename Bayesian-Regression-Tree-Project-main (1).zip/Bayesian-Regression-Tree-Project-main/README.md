# Bayesian-Regression-Tree-Project
BARTMachine tests and reproduction of the tests done in the BARTMachine documentation. Please follow the setup instructions from here
https://github.com/kapelner/bartMachine

